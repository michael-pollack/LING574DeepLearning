#!/bin/sh
python /dropbox/23-24/574/check_hw.py /dropbox/23-24/574/languages /dropbox/23-24/574/hw1/submit-file-list hw1.tar.gz
